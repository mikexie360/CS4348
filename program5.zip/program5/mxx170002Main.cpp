/**************************************************************************
 * File: mxx170002Main.cpp
 * Author: Mork
 * Procedures:
 * main 	- Simulates HDD performance. FIFO, SSTF, SCAN and LIFO
***************************************************************************/
#include <iostream>
#include <string>
#include <random>
#include <sys/utsname.h>
#include <bits/stdc++.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <stdlib.h>
#include <cmath>

/**************************************************************************
 * int main()
 * Author: Mork
 * Date: 13 September 2020
 * Description: Simulates HDD performance. FIFO, SSTF, SCAN and LIFO
 *
 * Parameters: None
***************************************************************************/

int main() {
	
	// set up variables
	double FIFOAVGREQTIME = 0.0;
	double FIFOTOTALREQTIME = 0.0;
	double SSTFAVGREQTIME = 0.0;
	double SSTFTOTALREQTIME = 0.0;
	double SCANAVGREQTIME = 0.0;
	double SCANTOTALREQTIME = 0.0;
	double LIFOAVGREQTIME = 0.0;
	double LIFOTOTALREQTIME = 0.0;
	
	// what was given to us
	int HDDRPM = 12000;
	double AVGSEEKTIME = .0025;
	int TRANSFERRATE = 6; //GB/s
	int numberOfTracks = 201;
	int sectorsPerTrack = 360;
	int blockSize = 4; //KB
	
	int startingTrack = 100;
	int startingSector = 0;
	int currentTrack = 100;
	int currentSector = 0;
	
	// Generate Random track and sector
	srand(time(NULL));
	std::vector<int> track;
	std::vector<int> sector;
	
	// 50 to 150 with plus 10 as the iteration each time
	for ( int i = 50; i <=150; i = i + 10) {
		
		
		for ( int j = 0; j <1000; j++) {
			
			// random
			for (int index = 0; index < i; index++) {
				track.push_back(rand() % 202);
				sector.push_back(rand() % 361);
			}
			//----------------------------------------------------------------------------------------------------
			int tempTrack = 0;
			int tempSector = 0;
			currentTrack = startingTrack;
			currentSector = startingSector;
			// FIFO
			for ( int k = 0; k < i ; k++) {
				tempTrack = track.at(k);
				tempSector = sector.at(k);
				//seek time
				FIFOTOTALREQTIME += (((double)HDDRPM/60) / (double)numberOfTracks) * (double)(abs(currentTrack - tempTrack));
				//Rotational Latency
				FIFOTOTALREQTIME += (((double)HDDRPM/60) / (double)numberOfTracks*sectorsPerTrack)* (double)(abs(currentSector - tempSector));
				//transfer time
				FIFOTOTALREQTIME += ((double)(blockSize * 1000)/(double)(TRANSFERRATE*1000000000));
				currentTrack = tempTrack;
				currentSector = tempSector;
			}
			//----------------------------------------------------------------------------------------------------
			currentTrack = startingTrack;
			currentSector = startingSector;
			//SSTF
			int temp = 0;
			std::vector<int> sstfTrack = track;
			std::vector<int> sstfSector = sector;
			//sort with bubble sort
			for ( int a = 0; a < i-1; a++) {
				for ( int b = 0; b < i-a-1; b++) {
					if ( sstfTrack.at(b) > sstfTrack[b+i]) {
						temp = sstfTrack.at(b);
						sstfTrack.at(b) = sstfTrack[b+1];
						sstfTrack[b+1] = temp;
							
						temp = sstfSector.at(b);
						sstfSector.at(b) = sstfSector[b+1];
						sstfSector[b+1] = temp;
					}
				}
			}
			for ( int k = 0; k < i ; k++) {
				tempTrack = sstfTrack.at(k);
				tempSector = sstfSector.at(k);
				SSTFTOTALREQTIME += (((double)HDDRPM/60) / (double)numberOfTracks) * (double)(abs(currentTrack - tempTrack));
				SSTFTOTALREQTIME += (((double)HDDRPM/60) / (double)numberOfTracks*sectorsPerTrack)* (double)(abs(currentSector - tempSector));
				SSTFTOTALREQTIME += ((double)(blockSize * 1000)/(double)(TRANSFERRATE*1000000000));
				currentTrack = tempTrack;
				currentSector = tempSector;
			}
			//----------------------------------------------------------------------------------------------------
			currentTrack = startingTrack;
			currentSector = startingSector;
			//SCAN
			std::vector<int> leftTrack, rightTrack;
			std::vector<int> leftSector, rightSector;
			std::vector<int> scanSeekSeq;
			for ( int a = 0; a < i; a++) {
				if (sstfTrack[a] < startingTrack) {
					leftTrack.push_back(sstfTrack[a]);
					leftSector.push_back(sstfSector[a]);
				}
				if (sstfTrack[a] > startingTrack) {
					rightTrack.push_back(sstfTrack[a]);
					rightSector.push_back(sstfSector[a]);
				}
			}
			for ( int k = 0; k < 2; k++){
				//left
				if ( k == 0) {
					for ( int m = leftTrack.size() - 1; m >= 0; m--) {
						tempTrack = leftTrack.at(m);
						tempSector = leftSector.at(m);
						SCANTOTALREQTIME += (((double)HDDRPM/60) / (double)numberOfTracks) * (double)(abs(currentTrack - tempTrack));
						SCANTOTALREQTIME += (((double)HDDRPM/60) / (double)numberOfTracks*sectorsPerTrack)* (double)(abs(currentSector - tempSector));
						SCANTOTALREQTIME += ((double)(blockSize * 1000)/(double)(TRANSFERRATE*1000000000));
						currentTrack = tempTrack;
						currentSector = tempSector;
					}
				}
				//right
				if ( k == 0) {
					for ( int m = 0; m < rightTrack.size(); m++) {
						tempTrack = rightTrack.at(m);
						tempSector = rightSector.at(m);
						SCANTOTALREQTIME += (((double)HDDRPM/60) / (double)numberOfTracks) * (double)(abs(currentTrack - tempTrack));
						SCANTOTALREQTIME += (((double)HDDRPM/60) / (double)numberOfTracks*sectorsPerTrack)* (double)(abs(currentSector - tempSector));
						SCANTOTALREQTIME += ((double)(blockSize * 1000)/(double)(TRANSFERRATE*1000000000));
						currentTrack = tempTrack;
						currentSector = tempSector;
					}
				}
			}
			//------------------------------------------------------------------------------------------------------
			//LIFO
			currentTrack = startingTrack;
			currentSector = startingSector;
			for ( int k = i-1; k >= 0 ; k--) {
				tempTrack = track.at(k);
				tempSector = sector.at(k);
				//seek time
				LIFOTOTALREQTIME += (((double)HDDRPM/60) / (double)numberOfTracks) * (double)(abs(currentTrack - tempTrack));
				//Rotational Latency
				LIFOTOTALREQTIME += (((double)HDDRPM/60) / (double)numberOfTracks*sectorsPerTrack)* (double)(abs(currentSector - tempSector));
				//transfer time
				LIFOTOTALREQTIME += ((double)(blockSize * 1000)/(double)(TRANSFERRATE*1000000000));
				currentTrack = tempTrack;
				currentSector = tempSector;
			}
			// loading screen
			std::cout << "\rLOADING " << (j/10) << "% DONE";
		}
		// flush
		std::cout << "\r                               ";
		
		
		//find average
		FIFOAVGREQTIME = FIFOTOTALREQTIME/1000;
		SSTFAVGREQTIME = SSTFTOTALREQTIME/1000;
		SCANAVGREQTIME = SCANTOTALREQTIME/1000;
		LIFOAVGREQTIME = LIFOTOTALREQTIME/1000;

		//print out result
		std::cout << "\n------------------------------------------------------------------------\n";
		std::cout << "*-"<< i << " Requests -----------------------------------------------------------\n";
		std::cout << "\t FIFO Average Request Time = " << FIFOAVGREQTIME << " seconds " <<"\n";
		std::cout << "\t SSTF Average Request Time = " << SSTFAVGREQTIME << " seconds " <<"\n";
		std::cout << "\t SCAN Average Request Time = " << SCANAVGREQTIME << " seconds " <<"\n";
		std::cout << "\t LIFO Average Request Time = " << LIFOAVGREQTIME << " seconds " <<"\n";
		std::cout << "\n";

		//reset totals for next iteration
		FIFOTOTALREQTIME = 0;
		SSTFTOTALREQTIME = 0;
		SCANTOTALREQTIME = 0;
		LIFOTOTALREQTIME = 0;
	}
	
	
	return 0;
}