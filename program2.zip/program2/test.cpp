#include <semaphore.h>
#include <unistd.h>
#include <stdio.h>
#include <iostream>
using namespace std;

const int sizeofbuffer=1000;

void printbuffer() {
	std::cout<<sizeofbuffer<<"\n";
}


int main()
{
	printbuffer();
	return 0;
}
