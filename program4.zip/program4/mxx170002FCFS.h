/************************************************************************
 * File: mxx170002FCFS.h
 * Author: Mork
 * Procedures:
 * FCFSFindWaitTimes 		- Runs the FeedBack Schedule algorithm simulation
 * FCFSFindTurnAroundTimes 	- outputs the turnaround times for every process
 * FCFSFindTrTs				- outputs the normalized turnaround times for every process
 * FCFSFindAVGWaitingTime	- outputs the average waiting time
 * FCFSFindAVGTurnaroundTime- outputs the average turnaround time
 * FCFSFindAVGTrTs			- outputs the average normalized turn around time
 * *********************************************************************/
#ifndef FCFS_H
#define FCFS_H

#include <iostream>
#include <string>
#include <random>
#include <sys/utsname.h>
#include <bits/stdc++.h>

/*************************************************************************
 * std::vector<double> FCFSFindWaitTimes(std::vector<double> &queue, std::vector<double> &arrival)
 * Author: Mork
 * Date: 8 November 2020
 * Description: runs the FCFS algorithm simulation
 * 
 * Parameters:
 * 	queue					I/P	std::vector<double>				The process queue that holds the burst times
 * 	arrival					I/P	std::vector<double>				The process queue that hold the arrival times
 * ***********************************************************************/
std::vector<double> FCFSFindWaitTimes(std::vector<double> &queue, std::vector<double> &arrival); // calculate the wait times for each process. Length of every vector should be 1000

/*************************************************************************
 * std::vector<double> FCFSFindTurnAroundTimes(std::vector<double> &queue, std::vector<double> &wait)
 * Author: Mork
 * Date: 8 November 2020
 * Description: returns a vector of turnaround times.
 * 
 * Parameters:
 * 	queue					I/P	std::vector<double>				The process queue that holds the burst times
 * 	wait					I/P	std::vector<double>				The vector that hold the wait times
 * ***********************************************************************/
std::vector<double> FCFSFindTurnAroundTimes(std::vector<double> &queue, std::vector<double> &wait); // calculate the turnaround times for each process. Length of every vector should be 1000

/*************************************************************************
 * std::vector<double> FCFSFindTrTs(std::vector<double> &ts, std::vector<double> &r)
 * Author: Mork
 * Date: 8 November 2020
 * Description: returns a vector of normalized turnaround times.
 * 
 * Parameters:
 * 	ts					I/P	std::vector<double>				The vector that holds the service time
 * 	tr					I/P	std::vector<double>				The vector that holds the turnaround time
 * ***********************************************************************/
std::vector<double> FCFSFindTrTs(std::vector<double> &ts, std::vector<double> &tr);

/*************************************************************************
 * double FCFSFindAVGWaitingTime(std::vector<double> &wait)
 * Author: Mork
 * Date: 8 November 2020
 * Description: returns the average wait.
 * 
 * Parameters:
 * 	wait				I/P	double							The average wait
 * ***********************************************************************/
double FCFSFindAVGWaitingTime(std::vector<double> &wait); // calculate the average waiting time

/*************************************************************************
 * double FCFSFindAVGTurnaroundTime(std::vector<double> &turnaround)
 * Author: Mork
 * Date: 8 November 2020
 * Description: returns the average turnaround time
 * 
 * Parameters:
 * 	turnaround				I/P	double							The average turnaround Time
 * ***********************************************************************/
double FCFSFindAVGTurnaroundTime(std::vector<double> &turnaround); // calculate the average waiting time

/*************************************************************************
 * double FCFSFindAVGTrTs(std::vector<double> &TrTs)
 * Author: Mork
 * Date: 8 November 2020
 * Description: returns the average normalized turnaround time
 * 
 * Parameters:
 * 	TrTs				I/P	double							The average normalized turnaround Time
 * ***********************************************************************/
double FCFSFindAVGTrTs(std::vector<double> &TrTs); //

#endif