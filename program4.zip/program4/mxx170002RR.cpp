/************************************************************************
 * File: mxx170002RR.cpp
 * Author: Mork
 * Procedures:
 * RRFindCompTimes - Calculates the completion vector
 * RRFindTurnAroundTimes - find the vector of turnaround times
 * RRFindWaitTimes - Find the vector of wait times
 * RRFindTrTs - Find the vector of normalized turnaround times
 * RRFindAVGWaitingTime - Finds the average waiting time
 * RRFindAVGTurnaroundTime - Finds the average turnaround time
 * RRFindAVGTrTs - Finds the average normalized turnaround time
 * *********************************************************************/
#include <iostream>
#include <string>
#include <random>
#include <sys/utsname.h>
#include <bits/stdc++.h>
#include "mxx170002RR.h"

/*************************************************************************
 * std::vector<double> RRFindCompTimes(std::vector<double> &queue, std::vector<double> &arrival)
 * Author: Mork
 * Date: 8 November 2020
 * Description: calculates the completion time vector
 * 
 * Parameters:
 * 	queue					I/P	std::vector<double>				The process queue that holds the burst times
 * 	arrival					I/P	std::vector<double>				The process queue that hold the arrival times
 * ***********************************************************************/
std::vector<double> RRFindCompTimes(std::vector<double> &queue, std::vector<double> &arrival) { 
	std::vector<double> RRWaitTimes;
	std::vector<double> RRCompletionTime;
		
	for ( int i = 0; i < 1000; i++) {
		RRCompletionTime.push_back(0);
	}
	
	// make a deep copy of burst times into wait times
	for( int i = 0; i < 1000; i++) {
		RRWaitTimes.push_back(queue.at(i));
	}
	
	int t = 0;
	int arrivalTime = 0;
	
	// loop until value of element of RRWaitTimes is 0
	while(true) {
		bool done = true;
		for (int i = 0; i < 1000; i++) {
			if (RRWaitTimes.at(i) > 0.0) {
				done = false;
				if (RRWaitTimes.at(i) > 1.0 && arrival.at(i) <= arrivalTime) {
					t += 1.0;
					RRWaitTimes.at(i) -= 1.0;
					arrivalTime++;
				}
				else {
					if (arrival.at(i) <= arrivalTime) {
						arrivalTime++;
						t += RRWaitTimes.at(i);
						RRWaitTimes.at(i) = 0;
						RRCompletionTime.at(i) = t;
					}
				}
			}
		}
		if (done == true) {
			break;
		}
	}
	return RRCompletionTime;
}

/*************************************************************************
 * std::vector<double> RRFindTurnAroundTimes(std::vector<double> &comp, std::vector<double> &arrival)
 * Author: Mork
 * Date: 8 November 2020
 * Description: calculates the turnaround time vector
 * 
 * Parameters:
 * 	comp					I/P	std::vector<double>				The vector that holds the completion times
 * 	arrival					I/P	std::vector<double>				The process queue that hold the arrival times
 * ***********************************************************************/
std::vector<double> RRFindTurnAroundTimes(std::vector<double> &comp, std::vector<double> &arrival) {
	std::vector<double> RRTurnaroundTimes;
	
	for (int i = 0; i < 1000; i++) {
		RRTurnaroundTimes.push_back(comp.at(i) - arrival.at(i));
	}
	return RRTurnaroundTimes;
}

/*************************************************************************
 * std::vector<double> RRFindWaitTimes(std::vector<double> &queue, std::vector<double> &turn)
 * Author: Mork
 * Date: 8 November 2020
 * Description: calculates the vector of wait times
 * 
 * Parameters:
 * 	queue					I/P	std::vector<double>				The process queue that holds the burst times
 * 	turn					I/P	std::vector<double>				The vector that holds the turnaround time
 * ***********************************************************************/
std::vector<double> RRFindWaitTimes(std::vector<double> &queue, std::vector<double> &turn) {
	std::vector<double> RRWaitTimes;
	
	for (int i = 0; i < 1000; i++) {
		RRWaitTimes.push_back(turn.at(i) - queue.at(i));
	}
	return RRWaitTimes;
}

/*************************************************************************
 * std::vector<double> RRFindTrTs(std::vector<double> &ts, std::vector<double> &tr)
 * Author: Mork
 * Date: 8 November 2020
 * Description: calculates the vector of normalized turnaround times
 * 
 * Parameters:
 * 	ts					I/P	std::vector<double>				The vector of service times
 * 	tr					I/P	std::vector<double>				The vector of turnaround times
 * ***********************************************************************/
std::vector<double> RRFindTrTs(std::vector<double> &ts, std::vector<double> &tr) {
	std::vector<double> RRTrTs;
	
	for ( int i = 0; i < 1000; i++) {
		RRTrTs.push_back(tr.at(i) / ts.at(i));
	}
	return RRTrTs;
}

/*************************************************************************
 * double RRFindAVGWaitingTime(std::vector<double> &wait)
 * Author: Mork
 * Date: 8 November 2020
 * Description: calculates the average waiting time
 * 
 * Parameters:
 * 	wait				I/P	std::vector<double>				The vector of wait times
 * ***********************************************************************/
double RRFindAVGWaitingTime(std::vector<double> &wait) { 
	double totalWait = 0.0;
	
	for ( int i = 0; i < 1000; i++) {
		totalWait = totalWait + wait.at(i);
	}
	return totalWait/1000;
}

/*************************************************************************
 * double RRFindAVGTurnaroundTime(std::vector<double> &turnaround)
 * Author: Mork
 * Date: 8 November 2020
 * Description: calculates the average turnaround time
 * 
 * Parameters:
 * 	turnaround				I/P	std::vector<double>				The vector of turnaround times
 * ***********************************************************************/
double RRFindAVGTurnaroundTime(std::vector<double> &turnaround) {
	double turnaroundTime = 0.0;
	
	for ( int i = 0; i < 1000; i++) {
		turnaroundTime = turnaroundTime + turnaround.at(i);
	}
	return turnaroundTime/1000;
}

/*************************************************************************
 * double RRFindAVGTrTs(std::vector<double> &TrTs)
 * Author: Mork
 * Date: 8 November 2020
 * Description: calculates the average normalized turnaround time
 * 
 * Parameters:
 * 	TrTs				I/P	std::vector<double>				The vector of normalized turnaround times
 * ***********************************************************************/
double RRFindAVGTrTs(std::vector<double> &TrTs) {
	double avg = 0.0;
	
	for ( int i = 0; i < 1000; i++) {
		avg = avg + TrTs.at(i);
	}
	return avg/1000;
}	




















