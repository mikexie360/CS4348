/**************************************************************************
 * File: mxx170002Main.cpp
 * Author: Mork
 * Procedures:
 * main 	- Simulates CPU scheduling algorithms
***************************************************************************/#include <iostream>
#include <string>
#include <random>
#include <sys/utsname.h>
#include <bits/stdc++.h>
#include <iostream>
#include <fstream>
#include "mxx170002GenerateProcess.h"
#include "mxx170002FCFS.h"
#include "mxx170002RR.h"
#include "mxx170002HRRN.h"
#include "mxx170002FB.h"

/**************************************************************************
 * int main()
 * Author: Mork
 * Date: 13 September 2020
 * Description: Simulates FCFS, RR, HRRN, and FB scheduling programs.
 *
 * Parameters: None
***************************************************************************/

int main() {
	
	// set up random number generator
	std::default_random_engine generator;
	std::normal_distribution<double> distribution(10.0,5.0);
	
	// set up variables
	double FCFSAVGWAIT = 0.0;
	double FCFSAVGTAT = 0.0;
	double FCFSAVGTRTS = 0.0;
	
	double RRAVGWAIT = 0.0;
	double RRAVGTAT = 0.0;
	double RRAVGTRTS = 0.0;
	
	double HRRNAVGWAIT = 0.0;
	double HRRNAVGTAT = 0.0;
	double HRRNAVGTRTS = 0.0;
	
	double FBAVGWAIT = 0.0;
	double FBAVGTAT = 0.0;
	double FBAVGTRTS = 0.0;
	
	for ( int i = 0; i <1000; i++) {
		// assume all process arrive at almost the same time at 0.
		std::vector<double> processQueue;				// The doubles are the burst times, The processQueue.at(i) is the arival time in seconds minus 1.
		std::vector<double> processArrival;				// The arrival time for all processes.
		processQueue = GenerateOneThousandProcess(); 	// One thousand process is generated, with their burst times
		processArrival = GenerateOneThousandArrival();	// Generate One Thousand Arrival Time.
		
		// FCFS-------------------------------------------------------------------------------------------------------------
		std::vector<double> FCFSProcessWaitTimes;		// The wait time starts at 0, then we find wait times wt[i] = (bt[0] + bt[1] +...... bt[i-1]) - at[i], also known as the Finish Time
		std::vector<double> FCFSProcessTurnaroundTimes;	// The turnaround time = waitTime + burstTime
		std::vector<double> FCFSProcessTrTs;			// The Tr/Ts Times
		double FCFSAVGWaitTime;					// The totalWaitingTime / NumberOfProcesses. Also known as Average Finish Time
		double FCFSAVGTurnaroundTime;			// The totalTurnaroundTime / NumberOfProcesses
		double FCFSAVGTrTs;						// The Tr/TS Average
		
		// calculate variables
		FCFSProcessWaitTimes = FCFSFindWaitTimes(processQueue, processArrival);
		FCFSProcessTurnaroundTimes = FCFSFindTurnAroundTimes(processQueue, processArrival);
		FCFSProcessTrTs = FCFSFindTrTs(processQueue,FCFSProcessTurnaroundTimes);
		FCFSAVGWaitTime = FCFSFindAVGWaitingTime(FCFSProcessWaitTimes);
		FCFSAVGTurnaroundTime = FCFSFindAVGTurnaroundTime(FCFSProcessTurnaroundTimes);
		FCFSAVGTrTs = FCFSFindAVGTrTs(FCFSProcessTrTs);
		//------------------------------------------------------------------------------------------------------------------
		
		// RR --------------------------------------------------------------------------------------------------------------
		std::vector<double> RRProcessWaitTimes;		// The wait times
		std::vector<double> RRProcessTurnaroundTimes;	// The turnaround time = waitTime + burstTime
		std::vector<double> RRProcessTrTs;			// The Tr/Ts Times
		std::vector<double> RRProcessCompletionTimes;	// The completion time for each process
		
		double quantum = 1.0;
		double RRAVGWaitTime;					// The totalWaitingTime / NumberOfProcesses. Also known as Average Finish Time
		double RRAVGTurnaroundTime;				// The totalTurnaroundTime / NumberOfProcesses
		double RRAVGTrTs;						// The Tr/TS Average
		
		// calculate variables
		RRProcessCompletionTimes = RRFindCompTimes(processQueue, processArrival);
		RRProcessTurnaroundTimes = RRFindTurnAroundTimes(RRProcessCompletionTimes, processArrival);
		RRProcessWaitTimes = RRFindWaitTimes(processQueue, RRProcessTurnaroundTimes);
		RRProcessTrTs = RRFindTrTs(processQueue, RRProcessTurnaroundTimes);
		RRAVGWaitTime = RRFindAVGWaitingTime(RRProcessWaitTimes);
		RRAVGTurnaroundTime = RRFindAVGTurnaroundTime(RRProcessTurnaroundTimes);
		RRAVGTrTs = RRFindAVGTrTs(RRProcessTrTs);
		// -----------------------------------------------------------------------------------------------------------------
		
		// HRRN ------------------------------------------------------------------------------------------------------------
		std::vector<double> HRRNProcessWaitTimes;
		std::vector<double> HRRNProcessResponseRatioQueue;		// The response ratio queue
		std::vector<double> HRRNProcessArrival;
		std::vector<double> HRRNProcessBurst;
		std::vector<double> HRRNProcessCompleted;
		std::vector<double> HRRNProcessTurnaroundTimes;
		std::vector<double> HRRNProcessTrTs;
		
		double HRRNSumBurst = 0.0;
		
		HRRNProcessInitialize(processArrival, processQueue, HRRNProcessResponseRatioQueue, HRRNProcessArrival, HRRNProcessBurst, HRRNProcessCompleted, HRRNSumBurst);
		
		double HRRNAVGWaitTime;					// The totalWaitingTime / NumberOfProcesses. Also known as Average Finish Time
		double HRRNAVGTurnaroundTime;				// The totalTurnaroundTime / NumberOfProcesses
		double HRRNAVGTrTs;						// The Tr/TS Average
		
		// calculate variables
		HRRNrun(HRRNProcessArrival, HRRNSumBurst, HRRNProcessCompleted, HRRNProcessBurst, HRRNProcessWaitTimes, HRRNProcessTurnaroundTimes, HRRNProcessTrTs);
		HRRNFindAVG(HRRNProcessWaitTimes, HRRNProcessTurnaroundTimes, HRRNProcessTrTs, HRRNAVGWaitTime, HRRNAVGTurnaroundTime, HRRNAVGTrTs);
		// ----------------------------------------------------------------------------------------------------------------
		
		// FB -------------------------------------------------------------------------------------------------------------
		std::vector<double> FBProcessWaitTimes;
		std::vector<double> FBProcessQ0;				// RR is used
		std::vector<double> FBProcessQ1;				// RR
		std::vector<double> FBProcessQ2;				// FCFS is used
		std::vector<double> FBProcessTurnaroundTimes;	// The turnaround time = waitTime + burstTime
		std::vector<double> FBProcessTrTs;			// The Tr/Ts Times
		std::vector<double> FBProcessCompletionTimes;	// The completion time for each process

		double FBAVGWaitTime;					// The totalWaitingTime / NumberOfProcesses. Also known as Average Finish Time
		double FBAVGTurnaroundTime;				// The totalTurnaroundTime / NumberOfProcesses
		double FBAVGTrTs;						// The Tr/TS Average
		
		// calculate variables
		FBProcessInitialize(processQueue, processArrival, FBProcessWaitTimes,FBProcessQ0,FBProcessQ1,FBProcessQ2,FBProcessTurnaroundTimes,FBProcessTrTs, FBProcessCompletionTimes,FBAVGWaitTime,FBAVGTurnaroundTime,FBAVGTrTs, FBAVGWaitTime, FBAVGTurnaroundTime, FBAVGTrTs);
		// ----------------------------------------------------------------------------------------------------------------
		
		// sum everything
		FCFSAVGWAIT += FCFSAVGWaitTime;
		FCFSAVGTAT += FCFSAVGTurnaroundTime;
		FCFSAVGTRTS += FCFSAVGTrTs;
	
		RRAVGWAIT += RRAVGWaitTime;
		RRAVGTAT += RRAVGTurnaroundTime;
		RRAVGTRTS += RRAVGTrTs;
	
		HRRNAVGWAIT += HRRNAVGWaitTime;
		HRRNAVGTAT += HRRNAVGTurnaroundTime;
		HRRNAVGTRTS += HRRNAVGTrTs;
	
		FBAVGWAIT += FBAVGWaitTime;
		FBAVGTAT += FBAVGTurnaroundTime;
		FBAVGTRTS += FBAVGTrTs;	
		
		// loading screen
		if ( i <= 100 ) {
			std::cout << "\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b LOADING " << (i/10) << "% DONE" << std::flush;
		}
		else {
			std::cout << "\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b LOADING " << (i/10) << "% DONE" << std::flush;
		}
	}
	
	// get final results
	FCFSAVGWAIT = FCFSAVGWAIT/1000;
	FCFSAVGTAT = FCFSAVGTAT/1000;
	FCFSAVGTRTS = FCFSAVGTRTS/1000;
	
	RRAVGWAIT = RRAVGWAIT/1000;
	RRAVGTAT = RRAVGTAT/1000;
	RRAVGTRTS = RRAVGTRTS/1000;
	
	HRRNAVGWAIT = HRRNAVGWAIT/1000;
	HRRNAVGTAT = HRRNAVGTAT/1000;
	HRRNAVGTRTS = HRRNAVGTRTS/1000;
	
	FBAVGWAIT = FBAVGWAIT/1000;
	FBAVGTAT = FBAVGTAT/1000;
	FBAVGTRTS = FBAVGTRTS/1000;
	
	// print
	std::cout << "\n";
	std::cout << "*- FIRST COME FIRST SERVE -------------------------------------------\n";
	std::cout << "\t Average Wait Time: \t\t" << FCFSAVGWAIT << " seconds" << "\n";
	std::cout << "\t Average Turnaround Time: \t" << FCFSAVGTAT << " seconds" << "\n";
	std::cout << "\t Average Normalized TT: \t" << FCFSAVGTRTS << " seconds" << "\n";
	std::cout << "*--------------------------------------------------------------------\n\n";

	std::cout << "*- ROUND ROBIN -----------------------------------------------------\n";
	std::cout << "\t Average Wait Time: \t\t" << RRAVGWAIT << " seconds" << "\n";
	std::cout << "\t Average Turnaround Time: \t" << RRAVGTAT << " seconds" << "\n";
	std::cout << "\t Average Normalized TT: \t" << RRAVGTRTS << " seconds" << "\n";
	std::cout << "*--------------------------------------------------------------------\n\n";
	
	std::cout << "*- HIGHEST RESPONSE RATIO NEXT --------------------------------------\n";
	std::cout << "\t Average Wait Time: \t\t" << HRRNAVGWAIT << " seconds" << "\n";
	std::cout << "\t Average Turnaround Time: \t" << HRRNAVGTAT << " seconds" << "\n";
	std::cout << "\t Average Normalized TT: \t" << HRRNAVGTRTS << " seconds" << "\n";
	std::cout << "*--------------------------------------------------------------------\n\n";

	std::cout << "*- FEEDBACK --------------------------------------------------------\n";
	std::cout << "\t Average Wait Time: \t\t" << FBAVGWAIT << " seconds" << "\n";
	std::cout << "\t Average Turnaround Time: \t" << FBAVGTAT << " seconds" << "\n";
	std::cout << "\t Average Normalized TT: \t" << FBAVGTRTS << " seconds" << "\n";
	std::cout << "*--------------------------------------------------------------------\n\n";

	
	
	return 0;
}