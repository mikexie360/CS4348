/************************************************************************
 * File: mxx170002FB.h
 * Author: Mork
 * Procedures:
 * FBProcessInitialize - Runs the FeedBack Schedule algorithm simulation
 * *********************************************************************/
#ifndef FB_H
#define FB_H

#include <iostream>
#include <string>
#include <random>
#include <sys/utsname.h>
#include <bits/stdc++.h>

/*************************************************************************
 * void FBProcessInitialize(std::vector<double> &queue, std::vector<double> &arrival,std::vector<double> &FBProcessWaitTimes,std::vector<double> &FBProcessQ0,std::vector<double> &FBProcessQ1, std::vector<double> &FBProcessQ2, std::vector<double> &FBProcessTurnaroundTimes,std::vector<double> &FBProcessTrTs, std::vector<double> &FBProcessCompletionTimes, double &FBAVGWaitTime, double FBAVGTurnaroundTime, double &FBAVGTrTs, double &WaitingAVG, double &TurnaroundAVG, double &TrTsAVG)
 * Author: Mork
 * Date: 8 November 2020
 * Description: runs the FeedBack algorithm simulation
 * 
 * Parameters:
 * 	queue					I/P	std::vector<double>				The process queue that holds the burst times
 * 	arrival					I/P	std::vector<double>				The process queue that hold the arrival times
 *	FBProcessWaitTimes 		I/P	std::vector<double>				A vector that holds wait times
 *  FBProcessQ0				I/P	std::vector<double>				Holds Queue 1
 *  FBProcessQ1				I/P	std::vector<double>				Holds Queue 2
 *  FBProcessQ2				I/P	std::vector<double>				Holds Queue 3
 *	FBProcessTurnaroundTimesI/P	std::vector<double>				Holds Turnaround Times
 *	FBProcessTrTs			I/P	std::vector<double>				Holds The normalized Turnaround Times
 *	FBProcessCompletionTimes I/P	std::vector<double>			Holds information if a process is completed
 *  FBAVGWaitTime			I/P	double							The FB average wait time
 *  FBAVGTurnaroundTime		I/P	double							The FB average Turnaround time
 *  FBAVGTrTs				I/P	double							The FB avegage nomralized Turnaround time
 *  WaitingAVG				I/P	double							The average waiting time for this simulation
 *	TurnaroundAVG			I/P	double							The average turnaround time for this simulation
 *	TrTsAVG					I/P	double							The average normalized turnaround time for this simulation
 * ***********************************************************************/
void FBProcessInitialize(std::vector<double> &queue, std::vector<double> &arrival,std::vector<double> &FBProcessWaitTimes,std::vector<double> &FBProcessQ0,std::vector<double> &FBProcessQ1, std::vector<double> &FBProcessQ2, std::vector<double> &FBProcessTurnaroundTimes,std::vector<double> &FBProcessTrTs, std::vector<double> &FBProcessCompletionTimes, double &FBAVGWaitTime, double FBAVGTurnaroundTime, double &FBAVGTrTs, double &WaitingAVG, double &TurnaroundAVG, double &TrTsAVG);

#endif