/************************************************************************
 * File: mxx170002GenerateProcess.h
 * Author: Mork
 * Procedures:
 * GenerateOneThousandProcess 		- Creates 1000 processes with burst times
 * GenerateOneThousandArrival		- Generate 1000 arrival times
 * *********************************************************************/
#ifndef GENERATEPROCESS_H
#define GENERATEPROCESS_H

#include <iostream>
#include <string>
#include <random>
#include <sys/utsname.h>
#include <bits/stdc++.h>

/*************************************************************************
 * std::vector<double> GenerateOneThousandProcess()
 * Author: Mork
 * Date: 8 November 2020
 * Description: creates 1000 processes with burst times
 * 
 * Parameters:
		none
 * ***********************************************************************/
std::vector<double> GenerateOneThousandProcess(); //Generate 1000 processes

/*************************************************************************
 * std::vector<double> GenerateOneThousandProcess()
 * Author: Mork
 * Date: 8 November 2020
 * Description: creates 1000 arrival times
 * 
 * Parameters:
		none
 * ***********************************************************************/
std::vector<double> GenerateOneThousandArrival(); //Generate 1000 Arrival Times

#endif