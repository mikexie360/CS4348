/************************************************************************
 * File: mxx170002FCFS.cpp
 * Author: Mork
 * Procedures:
 * FCFSFindWaitTimes 		- Runs the FeedBack Schedule algorithm simulation
 * FCFSFindTurnAroundTimes 	- outputs the turnaround times for every process
 * FCFSFindTrTs				- outputs the normalized turnaround times for every process
 * FCFSFindAVGWaitingTime	- outputs the average waiting time
 * FCFSFindAVGTurnaroundTime- outputs the average turnaround time
 * FCFSFindAVGTrTs			- outputs the average normalized turn around time
 * *********************************************************************/
#include <iostream>
#include <string>
#include <random>
#include <sys/utsname.h>
#include <bits/stdc++.h>
#include "mxx170002FCFS.h"

/*************************************************************************
 * std::vector<double> FCFSFindWaitTimes(std::vector<double> &queue, std::vector<double> &arrival)
 * Author: Mork
 * Date: 8 November 2020
 * Description: runs the FCFS algorithm simulation
 * 
 * Parameters:
 * 	queue					I/P	std::vector<double>				The process queue that holds the burst times
 * 	arrival					I/P	std::vector<double>				The process queue that hold the arrival times
 * ***********************************************************************/
std::vector<double> FCFSFindWaitTimes(std::vector<double> &queue, std::vector<double> &arrival) {
	std::vector<double> FCFSServiceTimes;
	FCFSServiceTimes.push_back(0);
	std::vector<double> FCFSWaitTimes;
	FCFSWaitTimes.push_back(0);
	
	for ( int i = 1; i < 1000; i++) {
		FCFSServiceTimes.push_back(FCFSServiceTimes.at(i-1) + queue.at(i-1));
		
		FCFSWaitTimes.push_back(FCFSServiceTimes.at(i) - arrival.at(i));
	}
	return FCFSWaitTimes;
}

/*************************************************************************
 * std::vector<double> FCFSFindTurnAroundTimes(std::vector<double> &queue, std::vector<double> &wait)
 * Author: Mork
 * Date: 8 November 2020
 * Description: returns a vector of turnaround times.
 * 
 * Parameters:
 * 	queue					I/P	std::vector<double>				The process queue that holds the burst times
 * 	wait					I/P	std::vector<double>				The vector that hold the wait times
 * ***********************************************************************/
std::vector<double> FCFSFindTurnAroundTimes(std::vector<double> &queue, std::vector<double> &wait) {
	std::vector<double> FCFSTurnaroundTimes;
	
	for (int i = 0; i < 1000; i++) {
		FCFSTurnaroundTimes.push_back(queue.at(i) + wait.at(i));
	}
	return FCFSTurnaroundTimes;
}

/*************************************************************************
 * std::vector<double> FCFSFindTrTs(std::vector<double> &ts, std::vector<double> &r)
 * Author: Mork
 * Date: 8 November 2020
 * Description: returns a vector of normalized turnaround times.
 * 
 * Parameters:
 * 	ts					I/P	std::vector<double>				The vector that holds the service time
 * 	tr					I/P	std::vector<double>				The vector that holds the turnaround time
 * ***********************************************************************/
std::vector<double> FCFSFindTrTs(std::vector<double> &ts, std::vector<double> &tr) {
	std::vector<double> FCFSTrTs;
	
	for ( int i = 0; i < 1000; i++) {
		FCFSTrTs.push_back(tr.at(i) / ts.at(i));
	}
	return FCFSTrTs;
}

/*************************************************************************
 * double FCFSFindAVGWaitingTime(std::vector<double> &wait)
 * Author: Mork
 * Date: 8 November 2020
 * Description: returns the average wait.
 * 
 * Parameters:
 * 	wait				I/P	double							The average wait
 * ***********************************************************************/
double FCFSFindAVGWaitingTime(std::vector<double> &wait) { 
	double totalWait = 0.0;
	
	for ( int i = 0; i < 1000; i++) {
		totalWait = totalWait + wait.at(i);
	}
	return totalWait/1000;
}

/*************************************************************************
 * double FCFSFindAVGTurnaroundTime(std::vector<double> &turnaround)
 * Author: Mork
 * Date: 8 November 2020
 * Description: returns the average turnaround time
 * 
 * Parameters:
 * 	turnaround				I/P	double							The average turnaround Time
 * ***********************************************************************/
double FCFSFindAVGTurnaroundTime(std::vector<double> &turnaround) {
	double turnaroundTime = 0.0;
	
	for ( int i = 0; i < 1000; i++) {
		turnaroundTime = turnaroundTime + turnaround.at(i);
	}
	return turnaroundTime/1000;
}

/*************************************************************************
 * double FCFSFindAVGTrTs(std::vector<double> &TrTs)
 * Author: Mork
 * Date: 8 November 2020
 * Description: returns the average normalized turnaround time
 * 
 * Parameters:
 * 	TrTs				I/P	double							The average normalized turnaround Time
 * ***********************************************************************/
double FCFSFindAVGTrTs(std::vector<double> &TrTs) {
	double avg = 0.0;
	
	for ( int i = 0; i < 1000; i++) {
		avg = avg + TrTs.at(i);
	}
	return avg/1000;
}	



