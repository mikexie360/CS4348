/************************************************************************
 * File: mxx170002RR.h
 * Author: Mork
 * Procedures:
 * RRFindCompTimes - Calculates the completion vector
 * RRFindTurnAroundTimes - find the vector of turnaround times
 * RRFindWaitTimes - Find the vector of wait times
 * RRFindTrTs - Find the vector of normalized turnaround times
 * RRFindAVGWaitingTime - Finds the average waiting time
 * RRFindAVGTurnaroundTime - Finds the average turnaround time
 * RRFindAVGTrTs - Finds the average normalized turnaround time
 * *********************************************************************/
#ifndef RR_H
#define RR_H

#include <iostream>
#include <string>
#include <random>
#include <sys/utsname.h>
#include <bits/stdc++.h>

/*************************************************************************
 * std::vector<double> RRFindCompTimes(std::vector<double> &queue, std::vector<double> &arrival)
 * Author: Mork
 * Date: 8 November 2020
 * Description: calculates the completion time vector
 * 
 * Parameters:
 * 	queue					I/P	std::vector<double>				The process queue that holds the burst times
 * 	arrival					I/P	std::vector<double>				The process queue that hold the arrival times
 * ***********************************************************************/
std::vector<double> RRFindCompTimes(std::vector<double> &queue, std::vector<double> &arrival); // calculate the completion times for each process. Length of every vector should be 1000

/*************************************************************************
 * std::vector<double> RRFindTurnAroundTimes(std::vector<double> &comp, std::vector<double> &arrival)
 * Author: Mork
 * Date: 8 November 2020
 * Description: calculates the turnaround time vector
 * 
 * Parameters:
 * 	comp					I/P	std::vector<double>				The vector that holds the completion times
 * 	arrival					I/P	std::vector<double>				The process queue that hold the arrival times
 * ***********************************************************************/
std::vector<double> RRFindTurnAroundTimes(std::vector<double> &comp, std::vector<double> &arrival); // calculate the Turnaround Times times for each process. Length of every vector should be 1000

/*************************************************************************
 * std::vector<double> RRFindWaitTimes(std::vector<double> &queue, std::vector<double> &turn)
 * Author: Mork
 * Date: 8 November 2020
 * Description: calculates the vector of wait times
 * 
 * Parameters:
 * 	queue					I/P	std::vector<double>				The process queue that holds the burst times
 * 	turn					I/P	std::vector<double>				The vector that holds the turnaround time
 * ***********************************************************************/
std::vector<double> RRFindWaitTimes(std::vector<double> &queue, std::vector<double> &turn);


/*************************************************************************
 * std::vector<double> RRFindTrTs(std::vector<double> &ts, std::vector<double> &tr)
 * Author: Mork
 * Date: 8 November 2020
 * Description: calculates the vector of normalized turnaround times
 * 
 * Parameters:
 * 	ts					I/P	std::vector<double>				The vector of service times
 * 	tr					I/P	std::vector<double>				The vector of turnaround times
 * ***********************************************************************/
std::vector<double> RRFindTrTs(std::vector<double> &ts, std::vector<double> &tr);


/*************************************************************************
 * double RRFindAVGWaitingTime(std::vector<double> &wait)
 * Author: Mork
 * Date: 8 November 2020
 * Description: calculates the average waiting time
 * 
 * Parameters:
 * 	wait				I/P	std::vector<double>				The vector of wait times
 * ***********************************************************************/
double RRFindAVGWaitingTime(std::vector<double> &wait);

/*************************************************************************
 * double RRFindAVGTurnaroundTime(std::vector<double> &turnaround)
 * Author: Mork
 * Date: 8 November 2020
 * Description: calculates the average turnaround time
 * 
 * Parameters:
 * 	turnaround				I/P	std::vector<double>				The vector of turnaround times
 * ***********************************************************************/
double RRFindAVGTurnaroundTime(std::vector<double> &turnaround);

/*************************************************************************
 * double RRFindAVGTrTs(std::vector<double> &TrTs)
 * Author: Mork
 * Date: 8 November 2020
 * Description: calculates the average normalized turnaround time
 * 
 * Parameters:
 * 	TrTs				I/P	std::vector<double>				The vector of normalized turnaround times
 * ***********************************************************************/
double RRFindAVGTrTs(std::vector<double> &TrTs);
#endif





















