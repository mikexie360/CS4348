/************************************************************************
 * File: mxx170002GenerateProcess.cpp
 * Author: Mork
 * Procedures:
 * GenerateOneThousandProcess 		- Creates 1000 processes with burst times
 * GenerateOneThousandArrival		- Generate 1000 arrival times
 * *********************************************************************/
#include <iostream>
#include <string>
#include <random>
#include <sys/utsname.h>
#include <bits/stdc++.h>
#include "mxx170002GenerateProcess.h"

/*************************************************************************
 * std::vector<double> GenerateOneThousandProcess()
 * Author: Mork
 * Date: 8 November 2020
 * Description: creates 1000 processes with burst times
 * 
 * Parameters:
		none
 * ***********************************************************************/
std::vector<double> GenerateOneThousandProcess() {
	std::vector<double> process;
	std::default_random_engine generator;
	std::normal_distribution<double> distribution(10.0,5.0);
	for (int i = 0; i <1000; i++) {
		double randomNumber = distribution(generator);
		if ( randomNumber < 1 ) {
			i = i - 1;
		}
		else {
			process.push_back(randomNumber);
		}
	}
	return process;
}

/*************************************************************************
 * std::vector<double> GenerateOneThousandProcess()
 * Author: Mork
 * Date: 8 November 2020
 * Description: creates 1000 arrival times
 * 
 * Parameters:
		none
 * ***********************************************************************/
std::vector<double> GenerateOneThousandArrival() {
	std::vector<double> Arrival;
	for (int i = 0; i <1000; i++) {
		Arrival.push_back(i);
	}
	return Arrival;
}