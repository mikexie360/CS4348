/************************************************************************
 * File: mxx170002HRRN.cpp
 * Author: Mork
 * Procedures:
 * HRRNProcessInitialize 		- Initialize the variables
 * HRRNrun						- Runs The simulation
 * HRRNFindAVG					- Calculates the average
 * *********************************************************************/
#include <iostream>
#include <string>
#include <random>
#include <sys/utsname.h>
#include <bits/stdc++.h>
#include "mxx170002HRRN.h"

/*************************************************************************
 * void HRRNProcessInitialize(std::vector<double> &processArrival, std::vector<double> &processBurst, std::vector<double> &ratioQueue, std::vector<double> &HRRNarrival, std::vector<double> &HRRNburst, std::vector<double> &completed, double &sum)
 * Author: Mork
 * Date: 8 November 2020
 * Description: Initialize the variables for the simulation
 * 
 * Parameters:
 * 	processArrival					I/P	std::vector<double>		The vector that holds the burst times
 * 	arrival							I/P	std::vector<double>		The vector that holds the arrival times
 *  ratioQueue						I/P	std::vector<double>		The vector that holds the ratio Queue times
 * 	HRRNarrival						I/P	std::vector<double>		The vector that tells us what process to execute next
 *	HRRNburst						I/P	std::vector<double>		The vector that holds the burst times for the process
 * 	completed						I/P	std::vector<double>		The vector that tells us if a process is finished
 * 	sum								I/P	double					The sum of the bursts
 * ***********************************************************************/
void HRRNProcessInitialize(std::vector<double> &processArrival, std::vector<double> &processBurst, std::vector<double> &ratioQueue, std::vector<double> &HRRNarrival, std::vector<double> &HRRNburst, std::vector<double> &completed, double &sum) {
	
	for ( int i = 0; i < 1000; i++) {
		ratioQueue.push_back(0);
		HRRNarrival.push_back(0);
		HRRNburst.push_back(0);
		completed.push_back(0);
	}
	
	for ( int i = 0; i < 1000; i++) {
		HRRNarrival.at(i) = processArrival.at(i);
		HRRNburst.at(i) = processBurst.at(i);
		
		sum = sum + HRRNburst.at(i);
	}

}

/*************************************************************************
 * void HRRNrun(std::vector<double> &arrival, double &sum, std::vector<double> &completed, std::vector<double> &burst, std::vector<double> &wait, std::vector<double> &turnaroundtime, std::vector<double> &trts)
 * Author: Mork
 * Date: 8 November 2020
 * Description: runs the simulation
 * 
 * Parameters:
 * 	arrival							I/P	std::vector<double>		The vector that holds the arrival times
 * 	sum								I/P double						The sum
 *  completed						I/P	std::vector<double>		Tells us what process is finished
 * 	burst							I/P	std::vector<double>		The vector of burst times
 *	wait							I/P	std::vector<double>		The vector of wait times
 * 	turnaroundtime					I/P	std::vector<double>		The vector of turnaroundtime
 * 	trts							I/P	std::vector<double>		The vector of normalized turnaroundtime
 * ***********************************************************************/
void HRRNrun(std::vector<double> &arrival, double &sum, std::vector<double> &completed, std::vector<double> &burst, std::vector<double> &wait, std::vector<double> &turnaroundtime, std::vector<double> &trts) {
	
	for ( int i = 0; i < 1000; i++) {
		wait.push_back(0);
		turnaroundtime.push_back(0);
		trts.push_back(0);
	}
	
	for (int i = arrival.at(0); i < sum;) {
		double HRR = -1.0;
		double HRRhelper;
		
		int j;
		for ( int k = 0; k < 1000; k++) {
			if (arrival.at(k) <= i && completed.at(k) != 1.0) {
				HRRhelper = (burst.at(k) + (i - arrival.at(k))) / burst.at(k);
				
				if ( HRR < HRRhelper) {
					HRR = HRRhelper;
					j = k;
				}
			}
		}
		
		i += burst.at(j);
		wait.at(j) = i - arrival.at(j) - burst.at(j);
		turnaroundtime.at(j) = i - arrival.at(j);
		trts.at(j) = (turnaroundtime.at(j) / burst.at(j));
		completed.at(j) = 1.0;
	}
}

/*************************************************************************
 * void HRRNFindAVG(std::vector<double> &WaitTime, std::vector<double> &TurnaroundTime, std::vector<double> &TrTs, double &wait, double &turnaroundtime, double &trts)
 * Author: Mork
 * Date: 8 November 2020
 * Description: finds the average
 * 
 * Parameters:
 * 	WaitTime						I/P	std::vector<double>		The vector that holds the wait time
 * 	TurnaroundTime					I/P std::vector<double>		The vector of turnaround time
 *  TrTs							I/P	std::vector<double>		The vector that holds normalized turnaround time 
 * 	wait							I/P	double>					The average wait time
 *	turnaroundtime					I/P	double					The average turnaround time
 * 	trts							I/P	double					The average normalized turnaround time
 * ***********************************************************************/
void HRRNFindAVG(std::vector<double> &WaitTime, std::vector<double> &TurnaroundTime, std::vector<double> &TrTs, double &wait, double &turnaroundtime, double &trts) {
	wait = 0.0;
	turnaroundtime = 0.0;
	trts = 0.0;
	
	for ( int i = 0; i < 1000; i++) {
		wait = wait + WaitTime.at(i);
		turnaroundtime = turnaroundtime + TurnaroundTime.at(i);
		trts = trts + TrTs.at(i);
	}
	
	wait = wait / 1000;
	turnaroundtime = turnaroundtime/1000;
	trts = trts/1000;
}















