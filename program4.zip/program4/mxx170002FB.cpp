/************************************************************************
 * File: mxx170002FB.cpp
 * Author: Mork
 * Procedures:
 * FBProcessInitialize - Runs the FeedBack Schedule algorithm simulation
 * *********************************************************************/
#include <iostream>
#include <string>
#include <random>
#include <sys/utsname.h>
#include <bits/stdc++.h>
#include "mxx170002FB.h"
/*************************************************************************
 * void FBProcessInitialize(std::vector<double> &queue, std::vector<double> &arrival,std::vector<double> &FBProcessWaitTimes,std::vector<double> &FBProcessQ0,std::vector<double> &FBProcessQ1, std::vector<double> &FBProcessQ2, std::vector<double> &FBProcessTurnaroundTimes,std::vector<double> &FBProcessTrTs, std::vector<double> &FBProcessCompletionTimes, double &FBAVGWaitTime, double FBAVGTurnaroundTime, double &FBAVGTrTs, double &WaitingAVG, double &TurnaroundAVG, double &TrTsAVG)
 * Author: Mork
 * Date: 8 November 2020
 * Description: runs the FeedBack algorithm simulation
 * 
 * Parameters:
 * 	queue					I/P	std::vector<double>				The process queue that holds the burst times
 * 	arrival					I/P	std::vector<double>				The process queue that hold the arrival times
 *	FBProcessWaitTimes 		I/P	std::vector<double>				A vector that holds wait times
 *  FBProcessQ0				I/P	std::vector<double>				Holds Queue 1
 *  FBProcessQ1				I/P	std::vector<double>				Holds Queue 2
 *  FBProcessQ2				I/P	std::vector<double>				Holds Queue 3
 *	FBProcessTurnaroundTimesI/P	std::vector<double>				Holds Turnaround Times
 *	FBProcessTrTs			I/P	std::vector<double>				Holds The normalized Turnaround Times
 *	FBProcessCompletionTimes I/P	std::vector<double>			Holds information if a process is completed
 *  FBAVGWaitTime			I/P	double							The FB average wait time
 *  FBAVGTurnaroundTime		I/P	double							The FB average Turnaround time
 *  FBAVGTrTs				I/P	double							The FB avegage nomralized Turnaround time
 *  WaitingAVG				I/P	double							The average waiting time for this simulation
 *	TurnaroundAVG			I/P	double							The average turnaround time for this simulation
 *	TrTsAVG					I/P	double							The average normalized turnaround time for this simulation
 * ***********************************************************************/
void FBProcessInitialize(std::vector<double> &queue, std::vector<double> &arrival,std::vector<double> &FBProcessWaitTimes,std::vector<double> &FBProcessQ0,std::vector<double> &FBProcessQ1, std::vector<double> &FBProcessQ2, std::vector<double> &FBProcessTurnaroundTimes,std::vector<double> &FBProcessTrTs, std::vector<double> &FBProcessCompletionTimes, double &FBAVGWaitTime, double FBAVGTurnaroundTime, double &FBAVGTrTs, double &WaitingAVG, double &TurnaroundAVG, double &TrTsAVG) {
	
	std::vector<double> FBWaitTimes;
	std::vector<double> FBArrivalQ0;
	std::vector<double> FBArrivalQ1;
	std::vector<double> FBArrivalQ2;
	
	for ( int i = 0; i < 1000; i++) {
		FBProcessWaitTimes.push_back(0);
		FBProcessQ0.push_back(0);
		
		FBProcessTurnaroundTimes.push_back(0);
		FBProcessTrTs.push_back(0);
	}
	
	// make a deep copy of process in queue into queue 0
	for( int i = 0; i < 1000; i++) {
		FBProcessQ0.at(i) = queue.at(i); 
		FBArrivalQ0.push_back(arrival.at(i));
	}
	
	// make a deep copy of burst times into wait times
	for( int i = 0; i < 1000; i++) {
		FBWaitTimes.push_back(queue.at(i));
	}
	
	double t1 = 0.0;
	double t2 = 0.0;
	int size0;
	std::vector<double> FBProcessCompletionTimes0;
	// loop until all processes are completed or shifted down into the next queue.
	while(true) {
		bool done = true;
		for ( int i = 0; i < FBProcessQ0.size(); i++){
			if ( FBProcessQ0.at(i) > 0.0) {
				done =false;
				if ( FBProcessQ0.at(i) > 1.0) {			//execute
					t1 += 1.0;
					FBProcessQ0.at(i) -= 1.0;
					FBProcessQ1.push_back(FBProcessQ0.at(i));
					FBArrivalQ1.push_back(FBArrivalQ0.at(i));
					FBProcessQ0.at(i) = 0;		
				}
				else {				// last time to execute
					t1 += FBProcessQ0.at(i);
					FBProcessQ0.at(i) = 0;
					FBProcessCompletionTimes0.push_back(t1);
				}
			}
		}
		if (done == true) {
			break;
		}
	}
	std::vector<double> FBProcessCompletionTimes1;
	// loop until all process are completed or shifted down the next queue.
	while(true) {
		bool done = true;
		for ( int i = 0; i < FBProcessQ1.size(); i++){
			if ( FBProcessQ1.at(i) > 0.0) {
				done =false;
				if ( FBProcessQ1.at(i) > 1.0) {			//execute
					t2 += 1.0;
					FBProcessQ1.at(i) -= 1.0;
					FBProcessQ2.push_back(FBProcessQ1.at(i));
					FBArrivalQ2.push_back(FBArrivalQ1.at(i));
					FBProcessQ1.at(i) = 0;		
				}
				else {				// last time to execute
					t2 += FBProcessQ1.at(i);
					FBProcessQ1.at(i) = 0;
					FBProcessCompletionTimes1.push_back(t2);
				}
			}
			
		}
		if (done == true) {
			break;
		}
	}
	
	// Q2 first come first serve
	std::vector<double> FCFSServiceTimes;
	FCFSServiceTimes.push_back(0);
	std::vector<double> FCFSWaitTimes;
	FCFSWaitTimes.push_back(0);
	for ( int i = 1; i < FBProcessQ2.size(); i++) {
		FCFSServiceTimes.push_back(FCFSServiceTimes.at(i-1) + FBProcessQ2.at(i-1));
		
		FCFSWaitTimes.push_back(FCFSServiceTimes.at(i) - FBArrivalQ2.at(i));
	}
	double FCFSWaitSum = 0.0;
	for ( int i = 0; i < FBProcessQ2.size() ; i++) {
		FCFSWaitSum = FCFSWaitSum + FCFSWaitTimes.at(i);
	}
	std::vector<double> FCFSTurnaroundTimes;
	for (int i = 0; i < FBProcessQ2.size(); i++) {
		FCFSTurnaroundTimes.push_back(FBProcessQ2.at(i) + FCFSWaitTimes.at(i));
	}
	double FCFSTurnaroundSum = 0.0;
	for ( int i = 0; i < FBProcessQ2.size() ; i++) {
		FCFSTurnaroundSum = FCFSTurnaroundSum + FCFSTurnaroundTimes.at(i);
	}
	std::vector<double> FCFSTrTs;
	for ( int i = 0; i < FBProcessQ2.size(); i++) {
		FCFSTrTs.push_back(FCFSTurnaroundTimes.at(i) / FBProcessQ2.at(i));
	}
	double TrTsQ2 = 0.0;
	for ( int i = 0; i < FBProcessQ2.size(); i++) {
		TrTsQ2 = TrTsQ2 + FCFSTrTs.at(i);
	}
	// Q1 RoundRobin
	std::vector<double> RRTurnaroundTimesQ1;
	for (int i = 0; i < FBProcessCompletionTimes1.size(); i++) {
		RRTurnaroundTimesQ1.push_back(FBProcessCompletionTimes1.at(i) - FBArrivalQ1.at(i));
	}
	double turnaroundTimeQ1 = 0.0;
	for ( int i = 0; i < FBProcessCompletionTimes1.size(); i++) {
		turnaroundTimeQ1 = turnaroundTimeQ1 + RRTurnaroundTimesQ1.at(i);
	}
	std::vector<double> RRWaitTimesQ1;
	for (int i = 0; i < FBProcessCompletionTimes1.size(); i++) {
		RRWaitTimesQ1.push_back(RRTurnaroundTimesQ1.at(i) - FBProcessQ1.at(i));
	}
	double waitTimeQ1 = 0.0;
	for ( int i = 0; i < FBProcessCompletionTimes1.size(); i++) {
		waitTimeQ1= waitTimeQ1 + RRTurnaroundTimesQ1.at(i);
	}
	std::vector<double> RRTrTsQ1;
	for ( int i = 0; i < FBProcessCompletionTimes1.size(); i++) {
		RRTrTsQ1.push_back(RRTurnaroundTimesQ1.at(i) / FBProcessQ2.at(i));
	}
	double TrTsQ1 = 0.0;
	for ( int i = 0; i < FBProcessCompletionTimes1.size(); i++) {
		TrTsQ1 = TrTsQ1 + RRTrTsQ1.at(i);
	}
	
	//Q0 RoundRobin
	std::vector<double> RRTurnaroundTimesQ0;
	for (int i = 0; i < FBProcessCompletionTimes0.size(); i++) {
		RRTurnaroundTimesQ0.push_back(FBProcessCompletionTimes0[i] - arrival[i]);
	}
	double turnaroundTimeQ0 = 0.0;
	
	for ( int i = 0; i < FBProcessCompletionTimes0.size(); i++) {
		turnaroundTimeQ0 = turnaroundTimeQ0 + RRTurnaroundTimesQ0[i];
	}
	std::vector<double> RRWaitTimesQ0;
	for (int i = 0; i < FBProcessCompletionTimes0.size(); i++) {
		RRWaitTimesQ0.push_back(RRTurnaroundTimesQ0[i] - FBProcessQ0[i]);
	}
	double waitTimeQ0 = 0.0;
	for ( int i = 0; i < FBProcessCompletionTimes0.size(); i++) {
		waitTimeQ0= waitTimeQ0 + RRTurnaroundTimesQ0[i];
	}
	std::vector<double> RRTrTsQ0;
	for ( int i = 0; i < FBProcessCompletionTimes0.size(); i++) {
		RRTrTsQ0.push_back(RRTurnaroundTimesQ0[i] / FBProcessQ0[i]);
	}
	double TrTsQ0 = 0.0;
	for ( int i = 0; i < FBProcessCompletionTimes0.size(); i++) {
		TrTsQ0 = TrTsQ0 + RRTrTsQ0[i];
	}
	
	// Sum
	double SUMWAITING = FCFSWaitSum + waitTimeQ0 + waitTimeQ1;
	double SUMTURNAROUND = FCFSTurnaroundSum + turnaroundTimeQ0 + turnaroundTimeQ1;
	double SUMTrTs = TrTsQ2 + TrTsQ1 + TrTsQ0;
	
	WaitingAVG = SUMWAITING/1000;
	TurnaroundAVG = SUMTURNAROUND/1000;
	TrTsAVG = SUMTrTs/1000;	
}