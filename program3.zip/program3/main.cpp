/************************************************************************
 * File: main.cpp
 * Author: Mork
 * Procedures:
 * main		- runs the program, reads in the file and uses
 * 		banker's algorithm to determine if the array of processes
 * 		will deadlock or not
 * prompt	- prompts the user for a filepath
 * readNumber	- reads in a line from a file to get a number
 * readArrayOne - reads in a line from a file to get an array
 * *********************************************************************/
#include<iostream>
#include<algorithm>
#include<fstream>
#include<string>
#include<vector>

/*************************************************************************
 * std::string prompt()
 * Author: Mork
 * Date: 18 October 2020
 * Description: prompts the user to enter a filepath
 *
 * Parameters:
 * 	N\A
 * ***********************************************************************/
std::string prompt() {
	std::string filepath;
	std::cout << "Enter a file path or name\n";	// prompts the user to enter a filepath to be read in
	std::cin >> filepath;
	return filepath;
}

/*************************************************************************
 * int readNumber(std::ifstream& myfile)
 * Author: Mork
 * Date: 18 October 2020
 * Description: reads in a line from a file and returns an int
 * 
 * Parameters:
 * 	myfile	I/P	ifstream&	The file path that the user must enter
 * 	main	O/P	int		The number that is returned from reading the file
 * ***********************************************************************/
int readNumber(std::ifstream& myfile) {
	std::string line;
	if(myfile.is_open()) {			// if the file can be open and read
		std::getline(myfile, line);	// read in the file
		return std::stoi(line);		// convert the string to a int and return
	}
	else {					// if the file cannot be open and read
		std::cout << "READ ERROR: COULD NOT FIND NUMBER OF RESOURCES\n";
	}
	return 0;
}

/*************************************************************************
 * int readArrayOne(std::ifstream& myfile, int& numberofresources, std::vector<int> &rvector)
 * Author: Mork
 * Date: 18 October 2020
 * Description: reads in a line from a file and saves a vector that was referenced
 * 
 * Parameters:
 * 	myfile	I/P	ifstream&	The file path that was entered by the user
 * 	numberofresources	I/P	int&		The number of resources
 * 	rvector		I/P and O/P	std::vector<int>&	The referenced vector, it will also be the output since the rvector will change based on the line read from the file
 * ***********************************************************************/
void readArrayOne(std::ifstream& myfile,int& numberofresources, std::vector<int> &rvector) {
	std::string line;
	
	if(myfile.is_open()) {				// open the file
		std::getline(myfile, line);		// read a line
		std::string delimiter = "\t";		// file is seperated by tabs
		size_t pos = 0;
		std::string token;
		int number;

		int i = 0;
		while (i < numberofresources) {		// split the string into individual ints and push back in the vector.
			pos = line.find(delimiter);
			token = line.substr(0,pos);
			number = std::stoi(token);
			rvector.push_back( number );
			line.erase(0, pos + delimiter.length());
			i++;
		}
	}
	else {						// if the file cannot be opened and read
		std::cout << "READ ERROR: COULD NOT FIND NUMBER OF RESOURCES\n";
	}
	return;

}

/*************************************************************************
 * int main(int argc, char** argv)
 * Author: Mork
 * Date: 18 October 2020
 * Description: read in a file that contains processes and resource data,
 * 		then run banker's algorithm to see if a deadlock would occur
 * 		or print out the processes sequence.
 *
 * Parameters:
 * 	argc	I/P 	int	number of arguments on the command line (not used)
 * 	argv	I/P	char**	the arguments on the command line (not used)
 * 	main	O/P	int	status code (not used)
 *************************************************************************/
int main(int argc, char** argv) {
	
	std::string filepath = prompt();	// prompt the user for a filepath


	std::string line;			// a line on the file
	std::ifstream myfile;			// my file
	myfile.open(filepath);			// open the file
	
	int res = readNumber(myfile);		// read in the first line on the file as the number of resources
	std::cout << "NUMBER OF RESOURCES:\t";	
	std::cout << res << "\n";
	
	std::vector<int> rvector;		//read in the second line of the file as the resource vector
	readArrayOne(myfile, res , rvector);
	std::cout << "THE RESOURCE VECOTR:\t";
	for(int i = 0; i <rvector.size(); i++) {
		std::cout <<rvector[i] << "\t";
	}
	std::cout << "\n";

	int proc = readNumber(myfile);		// read in the third line of the file as the number of processses
	std::cout << "THE NUMBER OF PROCESSES:\t";
	std::cout << proc << "\n";
	
	int claim [proc] [res];			// read in the number of lines equal to processes from the file.
	if(myfile.is_open()) {
		int r = 0;
		while(r < proc) {
			std::getline(myfile, line);
			std::string delimiter = "\t";
			size_t pos = 0;
			std::string token;
			int number;
	
			int c = 0;
			while (c < res) {
				pos = line.find(delimiter);
				token = line.substr(0,pos);
				number = std::stoi(token);
				claim[r][c] = number;
				line.erase(0, pos + delimiter.length());
				c++;
			}
			r++;
		}
	}
	else {
		std::cout << "READ ERROR: COULD NOT FIND CLAIM MATRIX\n";
	}
	std::cout << "THE CLAIM MATRIX:\n";
	for ( int r = 0; r < proc; r++) {
		for ( int c = 0; c < res; c++) {
			std::cout << claim[r][c] << "\t";
		}
		std::cout << "\n";
	}


	int allocation [proc] [res];		// read in the number of lines equal to the number of processes from the file
	if(myfile.is_open()) {
		int r = 0;
		while(r<proc) {
			std::getline(myfile,line);
			std::string delimiter = "\t";
			size_t pos = 0;
			std::string token;
			int number;
	
			int c = 0;
			while (c < res) {
				pos = line.find(delimiter);
				token = line.substr(0,pos);
				number = std::stoi(token);
				allocation[r][c] = number;
				line.erase(0, pos + delimiter.length());
				c++;
			}
			r++;
		}
	}
	else {
		std::cout << "READ ERROR: COULD NOT FIND ALLOCATION MATRIX\n";
	}
	std::cout << "THE ALLOCATION MATRIX:\n";
	for ( int r = 0; r < proc; r++) {
		for ( int c = 0; c < res; c++) {
			std::cout << allocation[r][c] << "\t";
		}
		std::cout << "\n";
	}


	int need [proc] [res];			// calculate the need matrix
	for ( int r = 0; r < proc; r++) {	// need = claim - allocation
		for (int c = 0; c < res; c++) {
			need[r][c] = claim[r][c] - allocation[r][c];
		}
	}
	std::cout << "THE NEED MATRIX:\n";
	for ( int r = 0; r < proc; r++) {
		for ( int c = 0; c < res; c++) {
			std::cout << need[r][c] << "\t";
		}
		std::cout <<"\n";
	}
	
	std::vector<int> safeseq;		// the safe sequence vector

	int available [res];			// the available work vector
	for ( int r = 0; r < res; r++){
		int sum = 0;
		for ( int c = 0; c < proc; c++) {	// sum is a vector where each element is the sum of a column
			sum += allocation[c][r];
		}
		available[r] = rvector[r] - sum;	// available = resource vector - sum
	}

	myfile.close();					// close the file
	
	bool availableisbigger = true;		// the last step of the banker's algorithm
	bool alreadyinsafeseq = false;
	int lastfail = -1;
	{ 						// new scope
	int r = 0;					// r is the processes rows
	while (safeseq.size() < proc) {			// only break if the safe sequence vector size is not less than the number of processes. 
		for ( int c = 0; c < res; c++) {	// iterate through all resource columns
			if ( need[r][c] <= available[c]) {	// if available is bigger than need
				continue;
			}
			else {					// if available is not bigger than need.
				availableisbigger = false;	
			}
		}
		if ( availableisbigger ) {			// if available is bigger than need
			availableisbigger = true;
			for ( int c = 0; c < res; c++) {	// make a new available and add a new processes r into the new safe sequence vector
				available[c] = allocation[r][c] + available[c];
			}
			safeseq.push_back(r);			// push the processes r into the safe sequence vector
		}						// if available is not bigger than need
		else {
			availableisbigger = true;
			if ( lastfail < r) {			// update last failure processes if the last failed process was not recent enough.
				lastfail = r;
			}
			else if (lastfail == r) {		// if the last failed processes was already most recent, then declare that processes and resourcesses are in an unsafe state and exit out of the program.
				std::cout << "UNSAFE STATE\n";
				return 0;	
			}
		}
		r++;						// increment through the processes rows.
		if ( r == proc) {				// if we reached to the last processes row, go back to the top of the processes row and continue the loop.
			r = 0;
		}
		while (std::find(safeseq.begin(),safeseq.end(),r)!=safeseq.end()) {	// if the processes row already exists, then just increment, keep doing this until we find a new processes that is not in the safe sequence.
			r++;
		}	
	}}

	std::cout << "THE FINAL AVAILABLE WORK IS:\n";		//output the final available work vector
	for ( int i = 0; i < res; i++) {
		std::cout << available[i] << "\t";
	}
	std::cout <<"\n";

	std::cout << "SAFE STATE\n";
	std::cout << "THE SAFE SEQUENCE IS:\n";			// output the final safe sequence vector
	for ( int i = 0; i < safeseq.size(); i++) {
		std::cout << "Processes " << safeseq[i] << "\t";
	}


	return 0;
}
